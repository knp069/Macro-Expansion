#include<stdio.h>
#define k 5
#define add(a,b) (a+b)
#define sub(a,b) a-b
int main(){
printf("Hello World!!");
apk = 6;
int d = 5+8;
int add = 5;
int c = ((4+5)+5);
return 0;
}
